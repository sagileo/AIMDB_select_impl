
#include "executor.h"
class MyHashTable {
	public:
		struct list_head hash_row_table[TCP_HASH_SIZE];
		int64_t t_id;
		int64_t c_id;
		BasicType *t;
		int64_t offset;
		Filter *filter;
		int64_t cur_record_rank;

		MyHashTable(int64_t t_id, int64_t c_id, Conditions *where) {
			for (int i = 0; i < TCP_HASH_SIZE; i++)
				init_list_head(&hash_row_table[i]);
			this->t_id = t_id;
			this->c_id = c_id;
			filter = new Filter(this, t_id, where);
			// establish hash table by t_id and c_id
			RowTable* tp = (RowTable*)(g_catalog.getObjById(t_id));
			int64_t col_rank = tp->getColumnRank(c_id);
			this->t = tp->getRPattern().getColumnType(col_rank);
			int64_t record_num = tp->getMStorage().getRecordNum();
			int64_t record_rank = 0;
			this->offset = tp->getRPattern().getColumnOffset(col_rank);
			while(1)
			{
				if(filter->isEnd() == true)
					break;
				record_rank = *((int64_t*)(filter->getNext()));
				char *rp = tp->getMStorage().getRow(record_rank);
				int hash_key = hash8(rp+offset, t->getTypeSize());
				hash_row *hr = (hash_row*)malloc(sizeof(hash_row));
				init_list_head(&(hr->list));
				hr->record_rank = record_rank;
				list_add_tail(&(hr->list), &(hash_row_table[hash_key]));
			}
			cur_record_rank = -1;
		}

		int64_t lookup(char* data) {
			int hash_key = hash8(data, t->getTypeSize());
			RowTable* tp = (RowTable*)(g_catalog.getObjById(t_id));
			hash_row *hr = NULL;
			int flag = 0;
			list_for_each_entry(hr, &hash_row_table[hash_key], list)
			{
				char *rp = tp->getMStorage().getRow(hr->record_rank);
				if(t->cmpEQ(rp+offset, data) == true)
				{
					if(cur_record_rank == -1 || flag == 1)
						return cur_record_rank = hr->record_rank;
					if(hr->record_rank == cur_record_rank)
						flag = 1;
				}
			}
			return cur_record_rank = -1;
		}

};
